import { prisma } from "../../config/prisma.js";

function round2(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

export function calculateInvoiceTotals({ lineItems = [], tax = 0, discount = 0 }) {
  const subtotal = round2(lineItems.reduce((sum, item) => sum + Number(item.amount || 0), 0));
  const cleanTax = round2(Number(tax || 0));
  const cleanDiscount = round2(Number(discount || 0));
  const total = round2(Math.max(0, subtotal + cleanTax - cleanDiscount));
  return { subtotal, tax: cleanTax, discount: cleanDiscount, total };
}

export async function nextInvoiceNumber() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const prefix = `INV-${year}${month}-`;
  const latest = await prisma.invoice.findFirst({
    where: { invoiceNumber: { startsWith: prefix } },
    orderBy: { createdAt: "desc" },
    select: { invoiceNumber: true }
  });
  const nextSeq = latest ? Number(latest.invoiceNumber.split("-").pop() || 0) + 1 : 1;
  return `${prefix}${String(nextSeq).padStart(4, "0")}`;
}

export async function hydrateInvoice(invoiceId) {
  return prisma.invoice.findUnique({
    where: { id: invoiceId },
    include: {
      client: true,
      lineItems: { orderBy: { createdAt: "asc" } },
      payments: {
        include: { refunds: { orderBy: { createdAt: "desc" } } },
        orderBy: { paymentDate: "desc" }
      }
    }
  });
}
