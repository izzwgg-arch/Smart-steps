import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

dotenv.config({ path: "/opt/aba/server/.env" });

const prisma = new PrismaClient();

const email = "admin@apluscenter.local";
const fullName = "A+ Admin";
const role = "ADMIN";
const plainPassword = "Aplus!Admin2026";

async function main() {
  const passwordHash = await bcrypt.hash(plainPassword, 10);
  await prisma.user.upsert({
    where: { email },
    update: { fullName, role, passwordHash },
    create: { email, fullName, role, passwordHash }
  });
  console.log("ADMIN_READY");
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
