import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const runs = await prisma.payrollRun.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        createdBy: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
        _count: {
          select: {
            lines: true,
          },
        },
      },
    })

    return NextResponse.json({ runs })
  } catch (error: any) {
    console.error('Error fetching payroll runs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch payroll runs', details: error.message },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const {
      name,
      periodStart,
      periodEnd,
      sourceImportId,
      employeeRates,
    } = body

    if (!name || !periodStart || !periodEnd) {
      return NextResponse.json(
        { error: 'Name, period start, and period end are required' },
        { status: 400 }
      )
    }

    // Create the payroll run
    const payrollRun = await prisma.payrollRun.create({
      data: {
        name: name.trim(),
        periodStart: new Date(periodStart),
        periodEnd: new Date(periodEnd),
        createdByUserId: session.user.id,
        status: 'DRAFT',
        sourceImportId: sourceImportId || null,
      },
    })

    // Get import rows for the period if sourceImportId is provided
    let importRows: any[] = []
    if (sourceImportId) {
      importRows = await prisma.payrollImportRow.findMany({
        where: {
          importId: sourceImportId,
          linkedEmployeeId: { not: null },
          workDate: {
            gte: new Date(periodStart),
            lte: new Date(periodEnd),
          },
        },
        include: {
          linkedEmployee: true,
        },
      })
    } else {
      // If no sourceImportId, get all import rows for the period
      importRows = await prisma.payrollImportRow.findMany({
        where: {
          linkedEmployeeId: { not: null },
          workDate: {
            gte: new Date(periodStart),
            lte: new Date(periodEnd),
          },
        },
        include: {
          linkedEmployee: true,
        },
      })
    }

    // Aggregate by employee
    const employeeTotals = new Map<string, {
      employeeId: string
      employee: any
      totalMinutes: number
      totalHours: number
      hourlyRate: number
    }>()

    for (const row of importRows) {
      if (!row.linkedEmployeeId || !row.linkedEmployee) continue

      const employeeId = row.linkedEmployeeId
      const minutesWorked = row.minutesWorked || 0
      const hoursWorked = row.hoursWorked ? parseFloat(row.hoursWorked.toString()) : 0

      if (!employeeTotals.has(employeeId)) {
        // Get hourly rate from employeeRates override or employee default
        const hourlyRate = employeeRates?.[employeeId] 
          ? parseFloat(employeeRates[employeeId])
          : parseFloat(row.linkedEmployee.defaultHourlyRate.toString())

        employeeTotals.set(employeeId, {
          employeeId,
          employee: row.linkedEmployee,
          totalMinutes: 0,
          totalHours: 0,
          hourlyRate,
        })
      }

      const totals = employeeTotals.get(employeeId)!
      totals.totalMinutes += minutesWorked
      totals.totalHours += hoursWorked || (minutesWorked / 60)
    }

    // Create PayrollRunLine records
    const runLines = Array.from(employeeTotals.values()).map(totals => ({
      runId: payrollRun.id,
      employeeId: totals.employeeId,
      hourlyRateUsed: totals.hourlyRate,
      totalMinutes: totals.totalMinutes,
      totalHours: parseFloat(totals.totalHours.toFixed(2)),
      grossPay: parseFloat((totals.totalHours * totals.hourlyRate).toFixed(2)),
      amountPaid: 0,
      amountOwed: parseFloat((totals.totalHours * totals.hourlyRate).toFixed(2)),
      notes: null,
    }))

    await prisma.payrollRunLine.createMany({
      data: runLines,
    })

    // Fetch the created run with lines
    const createdRun = await prisma.payrollRun.findUnique({
      where: { id: payrollRun.id },
      include: {
        lines: {
          include: {
            employee: true,
          },
        },
      },
    })

    return NextResponse.json({ run: createdRun })
  } catch (error: any) {
    console.error('Error creating payroll run:', error)
    return NextResponse.json(
      { error: 'Failed to create payroll run', details: error.message },
      { status: 500 }
    )
  }
}
