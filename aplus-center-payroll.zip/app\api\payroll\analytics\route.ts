import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const dateStart = searchParams.get('dateStart')
    const dateEnd = searchParams.get('dateEnd')
    const runId = searchParams.get('runId')
    const employeeId = searchParams.get('employeeId')
    const paidStatus = searchParams.get('paidStatus') // 'unpaid', 'partial', 'paid'

    // Build where clause for runs
    const runWhere: any = {}
    if (dateStart) runWhere.periodStart = { gte: new Date(dateStart) }
    if (dateEnd) runWhere.periodEnd = { lte: new Date(dateEnd) }
    if (runId) runWhere.id = runId

    // Get payroll runs
    const runs = await prisma.payrollRun.findMany({
      where: runWhere,
      include: {
        lines: {
          include: {
            employee: true,
          },
        },
        payments: true,
      },
    })

    // Filter lines if employeeId is specified
    let allLines = runs.flatMap(run => 
      run.lines.map(line => ({
        ...line,
        runId: run.id,
        runName: run.name,
        runPeriodStart: run.periodStart,
      }))
    )

    if (employeeId) {
      allLines = allLines.filter(line => line.employeeId === employeeId)
    }

    // Filter by paid status
    if (paidStatus) {
      if (paidStatus === 'unpaid') {
        allLines = allLines.filter(line => parseFloat(line.amountOwed.toString()) > 0 && parseFloat(line.amountPaid.toString()) === 0)
      } else if (paidStatus === 'partial') {
        allLines = allLines.filter(line => parseFloat(line.amountOwed.toString()) > 0 && parseFloat(line.amountPaid.toString()) > 0)
      } else if (paidStatus === 'paid') {
        allLines = allLines.filter(line => parseFloat(line.amountOwed.toString()) <= 0)
      }
    }

    // Calculate totals
    const totalGross = allLines.reduce((sum, line) => sum + parseFloat(line.grossPay.toString()), 0)
    const totalPaid = allLines.reduce((sum, line) => sum + parseFloat(line.amountPaid.toString()), 0)
    const totalOwed = allLines.reduce((sum, line) => sum + parseFloat(line.amountOwed.toString()), 0)

    // Employee counts by status
    const unpaidEmployees = new Set(
      allLines
        .filter(line => parseFloat(line.amountOwed.toString()) > 0 && parseFloat(line.amountPaid.toString()) === 0)
        .map(line => line.employeeId)
    ).size

    const partialEmployees = new Set(
      allLines
        .filter(line => parseFloat(line.amountOwed.toString()) > 0 && parseFloat(line.amountPaid.toString()) > 0)
        .map(line => line.employeeId)
    ).size

    const paidEmployees = new Set(
      allLines
        .filter(line => parseFloat(line.amountOwed.toString()) <= 0)
        .map(line => line.employeeId)
    ).size

    // Payments over time (grouped by date)
    const paymentsByDate = runs.flatMap(run => run.payments).reduce((acc: Record<string, number>, payment) => {
      const dateKey = new Date(payment.paidAt).toISOString().split('T')[0]
      acc[dateKey] = (acc[dateKey] || 0) + parseFloat(payment.amount.toString())
      return acc
    }, {})

    const paymentsOverTime = Object.entries(paymentsByDate)
      .map(([date, amount]) => ({ date, amount }))
      .sort((a, b) => a.date.localeCompare(b.date))

    // Owed vs Paid by employee
    const employeeTotals = allLines.reduce((acc: Record<string, { name: string; owed: number; paid: number }>, line) => {
      const employeeId = line.employeeId
      if (!acc[employeeId]) {
        acc[employeeId] = {
          name: line.employee.fullName,
          owed: 0,
          paid: 0,
        }
      }
      acc[employeeId].owed += parseFloat(line.amountOwed.toString())
      acc[employeeId].paid += parseFloat(line.amountPaid.toString())
      return acc
    }, {})

    const owedVsPaidByEmployee = Object.values(employeeTotals)
      .sort((a, b) => b.owed - a.owed)
      .slice(0, 10) // Top 10 employees

    // Waterfall data: Gross Total → Paid → Remaining Owed
    const waterfallData = [
      { category: 'Gross Total', value: totalGross },
      { category: 'Paid', value: totalPaid },
      { category: 'Remaining Owed', value: totalOwed },
    ]

    return NextResponse.json({
      totalGross,
      totalPaid,
      totalOwed,
      employeeCount: {
        unpaid: unpaidEmployees,
        partial: partialEmployees,
        paid: paidEmployees,
        total: unpaidEmployees + partialEmployees + paidEmployees,
      },
      paymentsOverTime,
      owedVsPaidByEmployee,
      waterfallData,
    })
  } catch (error: any) {
    console.error('Error fetching payroll analytics:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics', details: error.message },
      { status: 500 }
    )
  }
}
