'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Save, Calendar, FileSpreadsheet, AlertCircle } from 'lucide-react'
import toast from 'react-hot-toast'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'

interface PayrollImport {
  id: string
  originalFileName: string
  status: 'DRAFT' | 'FINALIZED'
  periodStart: string | null
  periodEnd: string | null
}

export function NewPayrollRun() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [imports, setImports] = useState<PayrollImport[]>([])
  const [loadingImports, setLoadingImports] = useState(true)

  // Form state
  const [name, setName] = useState('')
  const [periodStart, setPeriodStart] = useState<Date | null>(null)
  const [periodEnd, setPeriodEnd] = useState<Date | null>(null)
  const [sourceType, setSourceType] = useState<'import' | 'daterange'>('daterange')
  const [sourceImportId, setSourceImportId] = useState<string>('')
  const [employeeRates, setEmployeeRates] = useState<Record<string, string>>({})

  useEffect(() => {
    fetchImports()
  }, [])

  const fetchImports = async () => {
    try {
      const response = await fetch('/api/payroll/imports')
      if (response.ok) {
        const data = await response.json()
        // Only show finalized imports
        const finalizedImports = (data.imports || []).filter(
          (imp: PayrollImport) => imp.status === 'FINALIZED'
        )
        setImports(finalizedImports)
      }
    } catch (error) {
      console.error('Failed to fetch imports:', error)
    } finally {
      setLoadingImports(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!name.trim()) {
      toast.error('Run name is required')
      return
    }

    if (!periodStart || !periodEnd) {
      toast.error('Period start and end dates are required')
      return
    }

    if (periodStart > periodEnd) {
      toast.error('Period start date must be before end date')
      return
    }

    if (sourceType === 'import' && !sourceImportId) {
      toast.error('Please select an import')
      return
    }

    setLoading(true)

    try {
      const response = await fetch('/api/payroll/runs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          periodStart: periodStart.toISOString(),
          periodEnd: periodEnd.toISOString(),
          sourceImportId: sourceType === 'import' ? sourceImportId : null,
          employeeRates: Object.keys(employeeRates).length > 0 ? employeeRates : undefined,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Failed to create payroll run')
      }

      const data = await response.json()
      toast.success('Payroll run created successfully!')
      router.push(`/payroll/runs/${data.run.id}`)
    } catch (error: any) {
      console.error('Error creating payroll run:', error)
      toast.error(error.message || 'Failed to create payroll run')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="px-4 py-6 sm:px-0">
      {/* Header */}
      <div className="mb-6">
        <Link
          href="/payroll/runs"
          className="flex items-center text-gray-600 hover:text-gray-900 mb-2"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Payroll Runs
        </Link>
        <h1 className="text-3xl font-bold text-gray-900">Create Payroll Run</h1>
        <p className="mt-2 text-sm text-gray-600">
          Create a new payroll run from finalized imports or date range
        </p>
      </div>

      {/* Form */}
      <div className="bg-white rounded-lg shadow p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Run Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Run Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Week of 2026-01-12"
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
            />
          </div>

          {/* Period Dates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Period Start <span className="text-red-500">*</span>
              </label>
              <DatePicker
                selected={periodStart}
                onChange={(date) => setPeriodStart(date)}
                dateFormat="MM/dd/yyyy"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                placeholderText="Select start date"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Period End <span className="text-red-500">*</span>
              </label>
              <DatePicker
                selected={periodEnd}
                onChange={(date) => setPeriodEnd(date)}
                dateFormat="MM/dd/yyyy"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                placeholderText="Select end date"
                required
              />
            </div>
          </div>

          {/* Source Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Data Source
            </label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="daterange"
                  checked={sourceType === 'daterange'}
                  onChange={(e) => setSourceType(e.target.value as 'daterange')}
                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">
                  All finalized imports within date range
                </span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="import"
                  checked={sourceType === 'import'}
                  onChange={(e) => setSourceType(e.target.value as 'import')}
                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">
                  Specific finalized import
                </span>
              </label>
            </div>
          </div>

          {/* Import Selection */}
          {sourceType === 'import' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Import <span className="text-red-500">*</span>
              </label>
              {loadingImports ? (
                <p className="text-sm text-gray-500">Loading imports...</p>
              ) : imports.length === 0 ? (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start">
                    <AlertCircle className="w-5 h-5 text-yellow-600 mr-2 mt-0.5" />
                    <div>
                      <p className="text-sm text-yellow-800">
                        No finalized imports available. Please finalize an import first.
                      </p>
                      <Link
                        href="/payroll/imports"
                        className="text-sm text-yellow-900 underline mt-1 inline-block"
                      >
                        Go to Imports
                      </Link>
                    </div>
                  </div>
                </div>
              ) : (
                <select
                  value={sourceImportId}
                  onChange={(e) => setSourceImportId(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="">Select an import...</option>
                  {imports.map((imp) => (
                    <option key={imp.id} value={imp.id}>
                      {imp.originalFileName}
                      {imp.periodStart && imp.periodEnd && (
                        ` (${new Date(imp.periodStart).toLocaleDateString()} - ${new Date(imp.periodEnd).toLocaleDateString()})`
                      )}
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> The system will automatically aggregate time logs by employee,
              calculate totals (hours/minutes), and compute gross pay based on each employee's
              default hourly rate. You can override hourly rates per employee after creation.
            </p>
          </div>

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-4 pt-4 border-t">
            <Link
              href="/payroll/runs"
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </Link>
            <button
              type="submit"
              disabled={loading || (sourceType === 'import' && imports.length === 0)}
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              <Save className="w-4 h-4 mr-2" />
              {loading ? 'Creating...' : 'Create Run'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
