import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import * as XLSX from 'xlsx'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const {
      fileData,
      mapping,
      fileName,
      periodStart,
      periodEnd,
    } = body

    if (!fileData || !mapping || !fileName) {
      return NextResponse.json(
        { error: 'Missing required fields: fileData, mapping, fileName' },
        { status: 400 }
      )
    }

    // Validate required mappings
    if (!mapping.workDate) {
      return NextResponse.json(
        { error: 'Work Date mapping is required' },
        { status: 400 }
      )
    }

    if (!mapping.employeeName && !mapping.employeeExternalId) {
      return NextResponse.json(
        { error: 'Either Employee Name or Employee External ID mapping is required' },
        { status: 400 }
      )
    }

    // Check that at least one time field is mapped
    const hasTimeMapping = 
      mapping.minutesWorked ||
      mapping.hoursWorked ||
      (mapping.inTime && mapping.outTime)

    if (!hasTimeMapping) {
      return NextResponse.json(
        { error: 'At least one time field must be mapped: Minutes Worked, Hours Worked, or both In Time and Out Time' },
        { status: 400 }
      )
    }

    // Parse file data
    let data: any[] = []
    
    if (fileData.type === 'excel') {
      const buffer = Buffer.from(fileData.buffer, 'base64')
      const workbook = XLSX.read(buffer, { type: 'buffer' })
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      data = XLSX.utils.sheet_to_json(worksheet, { raw: false, defval: '' })
    } else if (fileData.type === 'csv') {
      const buffer = Buffer.from(fileData.buffer, 'base64')
      // Parse CSV using XLSX (it can read CSV)
      const workbook = XLSX.read(buffer, { type: 'buffer' })
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      data = XLSX.utils.sheet_to_json(worksheet, { raw: false, defval: '' })
    }

    // Create PayrollImport record
    const payrollImport = await prisma.payrollImport.create({
      data: {
        originalFileName: fileName,
        uploadedByUserId: session.user.id,
        uploadedAt: new Date(),
        status: 'DRAFT',
        periodStart: periodStart ? new Date(periodStart) : null,
        periodEnd: periodEnd ? new Date(periodEnd) : null,
        mappingJson: mapping as any,
      },
    })

    // Process rows and create PayrollImportRow records
    const rows = data.map((row, index) => {
      const employeeNameRaw = mapping.employeeName ? row[mapping.employeeName]?.toString().trim() : null
      const employeeExternalIdRaw = mapping.employeeExternalId ? row[mapping.employeeExternalId]?.toString().trim() : null
      
      // Parse work date
      let workDate: Date | null = null
      if (mapping.workDate && row[mapping.workDate]) {
        const dateValue = row[mapping.workDate]
        if (dateValue instanceof Date) {
          workDate = dateValue
        } else if (typeof dateValue === 'string') {
          workDate = new Date(dateValue)
        } else if (typeof dateValue === 'number') {
          // Excel serial date
          workDate = new Date((dateValue - 25569) * 86400 * 1000)
        }
      }

      // Parse time fields
      let inTime: Date | null = null
      let outTime: Date | null = null
      let minutesWorked: number | null = null
      let hoursWorked: number | null = null

      if (mapping.inTime && row[mapping.inTime]) {
        const inTimeValue = row[mapping.inTime]
        if (inTimeValue instanceof Date) {
          inTime = inTimeValue
        } else if (typeof inTimeValue === 'string') {
          // Try to parse time string
          const timeMatch = inTimeValue.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?(\s*[AaPp][Mm])?/)
          if (timeMatch && workDate) {
            let hours = parseInt(timeMatch[1])
            const minutes = parseInt(timeMatch[2])
            const period = timeMatch[4]?.trim().toUpperCase()
            
            if (period === 'PM' && hours !== 12) hours += 12
            if (period === 'AM' && hours === 12) hours = 0

            inTime = new Date(workDate)
            inTime.setHours(hours, minutes, 0, 0)
          } else {
            inTime = new Date(inTimeValue)
          }
        }
      }

      if (mapping.outTime && row[mapping.outTime]) {
        const outTimeValue = row[mapping.outTime]
        if (outTimeValue instanceof Date) {
          outTime = outTimeValue
        } else if (typeof outTimeValue === 'string') {
          const timeMatch = outTimeValue.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?(\s*[AaPp][Mm])?/)
          if (timeMatch && workDate) {
            let hours = parseInt(timeMatch[1])
            const minutes = parseInt(timeMatch[2])
            const period = timeMatch[4]?.trim().toUpperCase()
            
            if (period === 'PM' && hours !== 12) hours += 12
            if (period === 'AM' && hours === 12) hours = 0

            outTime = new Date(workDate)
            outTime.setHours(hours, minutes, 0, 0)
            
            // Handle overnight shifts
            if (inTime && outTime < inTime) {
              outTime.setDate(outTime.getDate() + 1)
            }
          } else {
            outTime = new Date(outTimeValue)
          }
        }
      }

      // Calculate minutes/hours from in/out time
      if (inTime && outTime) {
        const diffMs = outTime.getTime() - inTime.getTime()
        minutesWorked = Math.floor(diffMs / (1000 * 60))
        hoursWorked = parseFloat((minutesWorked / 60).toFixed(2))
      } else if (mapping.minutesWorked && row[mapping.minutesWorked]) {
        const parsedMinutes = parseInt(row[mapping.minutesWorked])
        if (!isNaN(parsedMinutes)) {
          minutesWorked = parsedMinutes
          hoursWorked = parseFloat((minutesWorked / 60).toFixed(2))
        }
      } else if (mapping.hoursWorked && row[mapping.hoursWorked]) {
        const parsedHours = parseFloat(row[mapping.hoursWorked])
        if (!isNaN(parsedHours)) {
          hoursWorked = parsedHours
          minutesWorked = Math.round(hoursWorked * 60)
        }
      }

      return {
        importId: payrollImport.id,
        rowIndex: index,
        employeeNameRaw: employeeNameRaw || null,
        employeeExternalIdRaw: employeeExternalIdRaw || null,
        workDate: workDate || new Date(), // Default to today if not parsed
        inTime: inTime || null,
        outTime: outTime || null,
        minutesWorked: minutesWorked || null,
        hoursWorked: hoursWorked !== null ? hoursWorked : null,
        linkedEmployeeId: null,
        rawJson: row as any,
      }
    })

    // Create all import rows in a transaction
    await prisma.$transaction(
      rows.map(row => prisma.payrollImportRow.create({ data: row }))
    )

    return NextResponse.json({
      success: true,
      importId: payrollImport.id,
      rowCount: rows.length,
    })
  } catch (error: any) {
    console.error('Error saving import:', error)
    return NextResponse.json(
      { error: 'Failed to save import', details: error.message },
      { status: 500 }
    )
  }
}
