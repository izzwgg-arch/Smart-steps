import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const employees = await prisma.payrollEmployee.findMany({
      orderBy: { fullName: 'asc' },
    })

    return NextResponse.json({ employees })
  } catch (error: any) {
    console.error('Error fetching employees:', error)
    return NextResponse.json(
      { error: 'Failed to fetch employees', details: error.message },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const {
      fullName,
      email,
      phone,
      active,
      defaultHourlyRate,
      scannerExternalId,
      notes,
    } = body

    if (!fullName || !defaultHourlyRate) {
      return NextResponse.json(
        { error: 'Full name and default hourly rate are required' },
        { status: 400 }
      )
    }

    const employee = await prisma.payrollEmployee.create({
      data: {
        fullName: fullName.trim(),
        email: email?.trim() || null,
        phone: phone?.trim() || null,
        active: active !== undefined ? active : true,
        defaultHourlyRate: parseFloat(defaultHourlyRate),
        scannerExternalId: scannerExternalId?.trim() || null,
        notes: notes?.trim() || null,
      },
    })

    return NextResponse.json({ employee })
  } catch (error: any) {
    console.error('Error creating employee:', error)
    return NextResponse.json(
      { error: 'Failed to create employee', details: error.message },
      { status: 500 }
    )
  }
}
