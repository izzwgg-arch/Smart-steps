SELECT id, status, "scheduledSendAt", "sentAt", "errorMessage", "toEmail"
FROM "EmailQueueItem" 
WHERE id = 'cmkbtmne00007132pzt16qkzz';
