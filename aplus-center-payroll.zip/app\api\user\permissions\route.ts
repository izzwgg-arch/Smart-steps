import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { getUserPermissions } from '@/lib/permissions'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const permissions = await getUserPermissions(session.user.id)

    return NextResponse.json({
      permissions: Object.keys(permissions).map((name) => ({
        name,
        canView: permissions[name]?.canView || false,
        canCreate: permissions[name]?.canCreate || false,
        canUpdate: permissions[name]?.canUpdate || false,
        canDelete: permissions[name]?.canDelete || false,
      })),
      role: session.user.role,
    })
  } catch (error: any) {
    console.error('Error fetching user permissions:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch permissions' },
      { status: 500 }
    )
  }
}
