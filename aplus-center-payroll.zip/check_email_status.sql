SELECT id, status, "scheduledSendAt", "sentAt", "errorMessage", "toEmail"
FROM "EmailQueueItem" 
WHERE id = 'cmkbk9e1u0004qnoy52zxpu9u';
