import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ clientId: string; goalId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { goalId } = await params;

  try {
    const body = await req.json();
    const { title, description, notes, sortOrder } = body;

    if (!title?.trim()) return NextResponse.json({ error: "Title required" }, { status: 400 });

    const existing = await prisma.subGoal.count({ where: { parentGoalId: goalId } });

    const subGoal = await prisma.subGoal.create({
      data: {
        parentGoalId: goalId,
        title: title.trim(),
        description: description?.trim() || null,
        notes: notes?.trim() || null,
        sortOrder: sortOrder ?? existing,
        status: "ACTIVE",
      },
    });

    return NextResponse.json(subGoal, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to create sub-goal" }, { status: 500 });
  }
}
