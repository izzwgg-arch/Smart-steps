import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ clientId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { clientId } = await params;

  try {
    const assessments = await prisma.clientAssessment.findMany({
      where: { clientId },
      orderBy: { startedAt: "desc" },
      include: {
        template: { select: { id: true, name: true, category: true, scoringMethod: true } },
        completedBy: { select: { name: true } },
        _count: { select: { responses: true } },
      },
    });

    return NextResponse.json(assessments);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ clientId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { clientId } = await params;

  try {
    const body = await req.json();
    const { templateId } = body;

    if (!templateId) return NextResponse.json({ error: "templateId required" }, { status: 400 });

    const assessment = await prisma.clientAssessment.create({
      data: {
        clientId,
        templateId,
        completedById: session.user.id,
        status: "IN_PROGRESS",
      },
      include: {
        template: {
          include: {
            sections: {
              orderBy: { sortOrder: "asc" },
              include: { items: { orderBy: { sortOrder: "asc" } } },
            },
          },
        },
      },
    });

    return NextResponse.json(assessment, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to create assessment" }, { status: 500 });
  }
}
