import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { Prisma } from "@prisma/client";

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const items = await prisma.targetLibraryItem.findMany({
      orderBy: { updatedAt: "desc" }
    });
    return NextResponse.json(items);
  } catch (err) {
    console.error("GET /api/target-library error:", err);
    return NextResponse.json({ error: "Failed to load library" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json() as {
      title?: string;
      operationalDefinition?: string | null;
      targetType?: string;
      masteryRule?: unknown;
      promptHierarchy?: string[];
      baseline?: string | null;
      notes?: string | null;
    };

    if (!body.title?.trim()) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 });
    }

    const item = await prisma.targetLibraryItem.create({
      data: {
        title: body.title.trim(),
        operationalDefinition: body.operationalDefinition?.trim() || null,
        targetType: body.targetType || "DISCRETE_TRIAL",
        masteryRule: body.masteryRule ?? Prisma.JsonNull,
        promptHierarchy: Array.isArray(body.promptHierarchy) ? body.promptHierarchy : [],
        baseline: body.baseline?.trim() || null,
        notes: body.notes?.trim() || null,
        createdById: session.user.id
      }
    });

    return NextResponse.json(item, { status: 201 });
  } catch (err) {
    console.error("POST /api/target-library error:", err);
    return NextResponse.json({ error: "Failed to save library item" }, { status: 500 });
  }
}
