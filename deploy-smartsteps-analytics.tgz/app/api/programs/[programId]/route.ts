import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { auditLog } from "@/lib/auditLogger";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ programId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { programId } = await params;
  try {
    const program = await prisma.program.findUnique({
      where: { id: programId },
      include: { targets: { orderBy: { createdAt: "asc" } } },
    });
    if (!program) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(program);
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ programId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const role = (session.user as { role?: string }).role;
  if (role === "RBT") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { programId } = await params;
  try {
    const body = await req.json() as { name?: string; domain?: string; isActive?: boolean };
    const updated = await prisma.program.update({ where: { id: programId }, data: body });
    await auditLog(session.user.id!, "UPDATE_PROGRAM", "Program", programId, { changes: body });
    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ programId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { programId } = await params;
  try {
    await prisma.program.update({ where: { id: programId }, data: { isActive: false } });
    await auditLog(session.user.id!, "UPDATE_PROGRAM", "Program", programId, { action: "archive" });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
