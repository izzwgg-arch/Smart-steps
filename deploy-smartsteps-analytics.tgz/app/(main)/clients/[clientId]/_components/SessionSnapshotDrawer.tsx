"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Activity, Clock, Target as TargetIcon, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

type SessionTargetSummary = {
  targetId: string;
  targetTitle: string;
  targetType: string;
  phase: string;
  parentGoalId: string | null;
  parentGoalTitle: string | null;
  subGoalId: string | null;
  subGoalTitle: string | null;
  programId: string | null;
  programName: string | null;
  providerId: string | null;
  providerName: string | null;
  sessionKind: string;
  trialCount: number;
  correctCount: number;
  promptedCount: number;
  incorrectCount: number;
  noResponseCount: number;
  maintenanceCount: number;
  promptCodes: Record<string, number>;
  notes: string[];
  percentage: number;
};

type SessionDetail = {
  id: string;
  clientId: string;
  userId: string | null;
  mode: string;
  startedAt: string;
  endedAt: string | null;
  notes: string | null;
  voiceNotes: string | null;
  user?: { id?: string | null; name?: string | null; email?: string | null } | null;
  trialCount: number;
  sessionTargets: SessionTargetSummary[];
};

export function SessionSnapshotDrawer({
  sessionId,
  onClose,
}: {
  sessionId: string | null;
  onClose: () => void;
}) {
  const { data, isLoading } = useQuery<SessionDetail>({
    queryKey: ["session-snapshot", sessionId],
    queryFn: async () => {
      if (!sessionId) {
        throw new Error("Missing session id");
      }
      const res = await fetch(`/smart-steps/api/sessions/${sessionId}`);
      if (!res.ok) throw new Error("Failed to load session snapshot");
      return res.json();
    },
    enabled: !!sessionId,
    staleTime: 30_000,
  });

  return (
    <AnimatePresence>
      {sessionId && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-sm"
        >
          <motion.div
            initial={{ x: 360 }}
            animate={{ x: 0 }}
            exit={{ x: 360 }}
            className="flex h-full w-full max-w-2xl flex-col border-l border-[var(--glass-border)] bg-[var(--background)]/95"
          >
            <div className="flex items-center gap-3 border-b border-[var(--glass-border)] px-5 py-4">
              <div className="rounded-xl bg-[var(--accent-cyan)]/10 p-2 text-[var(--accent-cyan)]">
                <Activity className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold text-[var(--foreground)]">Session Snapshot</div>
                <div className="text-xs text-zinc-500">
                  {data ? new Date(data.startedAt).toLocaleString() : "Loading session details..."}
                </div>
              </div>
              <button type="button" onClick={onClose} className="rounded-xl p-2 text-zinc-400 hover:bg-white/10 hover:text-zinc-200">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5">
              {isLoading || !data ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((index) => (
                    <div key={index} className="h-24 rounded-2xl border border-[var(--glass-border)] bg-[var(--glass-bg)]/20" />
                  ))}
                </div>
              ) : (
                <div className="space-y-5">
                  <div className="grid gap-3 sm:grid-cols-4">
                    {[
                      { label: "Mode", value: data.mode },
                      { label: "Provider", value: data.user?.name || "—" },
                      { label: "Trials", value: String(data.trialCount) },
                      {
                        label: "Duration",
                        value: data.endedAt
                          ? `${Math.max(1, Math.round((new Date(data.endedAt).getTime() - new Date(data.startedAt).getTime()) / 60000))} min`
                          : "In progress",
                      },
                    ].map((item) => (
                      <div key={item.label} className="rounded-2xl border border-[var(--glass-border)] bg-[var(--glass-bg)]/20 p-3">
                        <div className="text-[11px] uppercase tracking-wide text-zinc-500">{item.label}</div>
                        <div className="mt-1 text-sm font-semibold text-zinc-200">{item.value}</div>
                      </div>
                    ))}
                  </div>

                  {(data.notes || data.voiceNotes) && (
                    <div className="rounded-2xl border border-[var(--glass-border)] bg-[var(--glass-bg)]/20 p-4">
                      <div className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Session Notes</div>
                      {data.notes && <div className="mt-2 text-sm text-zinc-200">{data.notes}</div>}
                      {data.voiceNotes && <div className="mt-2 text-sm text-zinc-400">{data.voiceNotes}</div>}
                    </div>
                  )}

                  <div className="space-y-3">
                    <div className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Goals Worked</div>
                    {data.sessionTargets.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-[var(--glass-border)] p-6 text-sm text-zinc-500">
                        No target-level work was recorded for this session.
                      </div>
                    ) : (
                      data.sessionTargets.map((item) => (
                        <div key={item.targetId} className="rounded-2xl border border-[var(--glass-border)] bg-[var(--glass-bg)]/20 p-4">
                          <div className="flex items-start gap-3">
                            <div className="rounded-xl bg-[var(--accent-cyan)]/10 p-2 text-[var(--accent-cyan)]">
                              <TargetIcon className="h-4 w-4" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between gap-3">
                                <div className="min-w-0">
                                  <div className="truncate text-sm font-semibold text-zinc-100">{item.targetTitle}</div>
                                  <div className="text-xs text-zinc-500">
                                    {item.parentGoalTitle || item.programName || "Unassigned"}{item.subGoalTitle ? ` / ${item.subGoalTitle}` : ""}
                                  </div>
                                </div>
                                <div className={`text-sm font-bold ${item.percentage >= 80 ? "text-emerald-300" : item.percentage >= 60 ? "text-amber-300" : "text-rose-300"}`}>
                                  {item.percentage}%
                                </div>
                              </div>
                              <div className="mt-3 grid gap-2 text-xs text-zinc-400 sm:grid-cols-4">
                                <div><span className="text-zinc-500">Trials:</span> {item.trialCount}</div>
                                <div><span className="text-zinc-500">Prompts:</span> {Object.keys(item.promptCodes).join(", ") || "Independent"}</div>
                                <div><span className="text-zinc-500">Therapist:</span> {item.providerName || "—"}</div>
                                <div><span className="text-zinc-500">Status that day:</span> {item.phase}</div>
                              </div>
                              {item.notes.length > 0 && (
                                <div className="mt-3 rounded-xl border border-[var(--glass-border)] bg-black/10 p-3 text-xs text-zinc-300">
                                  {item.notes.join(" | ")}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between border-t border-[var(--glass-border)] px-5 py-3 text-xs text-zinc-500">
              <div className="flex items-center gap-2">
                <Clock className="h-3.5 w-3.5" />
                Historical session details are read-only here.
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
