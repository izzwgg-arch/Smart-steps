/**
 * Ensures the authenticated user exists in the Smart Steps User table.
 *
 * Smart Steps uses NextAuth which returns a session.user.id that comes from
 * the main A+ Center app's JWT (SSO). That ID does NOT automatically exist
 * in the smart_steps.User table, causing FK constraint failures on any write
 * (Session, Target, ParentGoal, etc.) that references userId.
 *
 * Call this at the top of any API route that creates/updates records with a userId.
 */

import { prisma } from "@/lib/db";

type AuthUser = {
  id: string;
  email?: string | null;
  name?: string | null;
  role?: string;
};

const VALID_ROLES = ["RBT", "BCBA", "ADMIN"] as const;
type Role = (typeof VALID_ROLES)[number];

function safeRole(r: string | undefined): Role {
  return VALID_ROLES.includes(r as Role) ? (r as Role) : "RBT";
}

export async function ensureUser(user: AuthUser): Promise<void> {
  const email = user.email?.trim() || `sso-${user.id}@smart-steps.local`;
  try {
    await prisma.user.upsert({
      where: { id: user.id },
      update: {
        // Keep name/email in sync if they change
        name: user.name ?? undefined,
        email,
      },
      create: {
        id: user.id,
        email,
        name: user.name ?? "Therapist",
        role: safeRole(user.role),
      },
    });
  } catch {
    // If upsert fails (e.g. email unique conflict from different account),
    // try updating by email instead, or just continue — sessions degrade gracefully.
    try {
      await prisma.user.upsert({
        where: { email },
        update: { name: user.name ?? undefined },
        create: {
          id: user.id,
          email: `sso-${user.id}@smart-steps.local`,
          name: user.name ?? "Therapist",
          role: safeRole(user.role),
        },
      });
    } catch {
      // Silent — better to attempt the main operation and let it surface a clear error
    }
  }
}
